<?php return array('dependencies' => array(), 'version' => 'c7a741f8dc5bec166999');
