<?php return array('dependencies' => array(), 'version' => '58bfe34a9c6c0d8c5093');
