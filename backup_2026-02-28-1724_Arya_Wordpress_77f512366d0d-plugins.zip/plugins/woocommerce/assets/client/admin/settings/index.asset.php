<?php return array('dependencies' => array('react', 'wc-settings-editor', 'wp-element'), 'version' => '6d709db587eb901109b9');
