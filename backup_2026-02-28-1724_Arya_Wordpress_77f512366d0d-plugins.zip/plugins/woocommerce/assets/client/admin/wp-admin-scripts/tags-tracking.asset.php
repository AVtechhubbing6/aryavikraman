<?php return array('dependencies' => array('wc-tracks'), 'version' => '3dc6e562849123db2043');
