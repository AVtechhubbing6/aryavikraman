<?php return array('dependencies' => array('wc-tracks'), 'version' => 'a66734416a4b6e6ebe43');
