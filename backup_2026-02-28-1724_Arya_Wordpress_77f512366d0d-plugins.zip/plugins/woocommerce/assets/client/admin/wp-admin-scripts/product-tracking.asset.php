<?php return array('dependencies' => array('wc-customer-effort-score', 'wc-tracks'), 'version' => '17e9dea0a5dd4c474e8f');
