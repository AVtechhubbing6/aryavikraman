<?php return array('dependencies' => array('wc-tracks'), 'version' => 'b2ef5aad1edda58f592d');
