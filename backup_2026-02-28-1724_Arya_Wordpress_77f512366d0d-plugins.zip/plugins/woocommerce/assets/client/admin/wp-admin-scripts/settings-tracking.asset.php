<?php return array('dependencies' => array('wc-customer-effort-score'), 'version' => '38098a31df4bc28089f4');
