<?php return array('dependencies' => array('react', 'wc-components', 'wc-store-data', 'wc-tracks', 'wp-element', 'wp-i18n'), 'version' => '74ced6030ed2c5695c70');
