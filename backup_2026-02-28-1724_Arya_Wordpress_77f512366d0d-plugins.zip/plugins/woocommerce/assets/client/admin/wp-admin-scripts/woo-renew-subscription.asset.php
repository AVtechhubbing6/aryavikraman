<?php return array('dependencies' => array('wc-tracks', 'wp-dom-ready'), 'version' => 'cfef7e65d3a3ba53ffe0');
