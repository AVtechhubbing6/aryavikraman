<?php return array('dependencies' => array('wc-customer-effort-score', 'wc-navigation'), 'version' => '94e70f6e49d03be8a094');
