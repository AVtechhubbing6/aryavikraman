<?php return array('dependencies' => array('wc-settings', 'wp-element', 'wp-i18n'), 'version' => '152f4925a74629e40842');
