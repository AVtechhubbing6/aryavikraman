<?php return array('dependencies' => array('wc-customer-effort-score'), 'version' => 'b18468e8225438c649f3');
