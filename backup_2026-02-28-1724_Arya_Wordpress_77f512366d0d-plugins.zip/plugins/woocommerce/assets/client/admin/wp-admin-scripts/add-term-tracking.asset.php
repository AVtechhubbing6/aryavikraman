<?php return array('dependencies' => array('wc-tracks'), 'version' => '806535d31ae8a5749983');
