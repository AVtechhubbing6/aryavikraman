<?php return array('dependencies' => array('wc-tracks', 'wp-dom-ready'), 'version' => '91cbaee934e5251b104b');
