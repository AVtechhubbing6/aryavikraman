<?php return array('dependencies' => array('wc-tracks', 'wp-dom-ready'), 'version' => 'b543742f543c862eb81e');
