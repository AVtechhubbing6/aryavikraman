<?php return array('dependencies' => array('react', 'wc-components', 'wc-tracks', 'wp-element', 'wp-hooks', 'wp-i18n'), 'version' => '7ce60805f51f40faa616');
