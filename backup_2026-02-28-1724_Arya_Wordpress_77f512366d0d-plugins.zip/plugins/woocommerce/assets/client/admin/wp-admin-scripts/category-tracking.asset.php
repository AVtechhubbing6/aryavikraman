<?php return array('dependencies' => array('wc-tracks'), 'version' => '90bec4928ec9e427bb01');
