<?php return array('dependencies' => array('wc-tracks', 'wp-dom-ready'), 'version' => '9464d8a999bb0fc57953');
