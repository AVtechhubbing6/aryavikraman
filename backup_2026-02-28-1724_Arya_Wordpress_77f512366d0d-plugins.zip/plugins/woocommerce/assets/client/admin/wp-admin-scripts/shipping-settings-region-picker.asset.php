<?php return array('dependencies' => array('react', 'wc-components', 'wp-element', 'wp-html-entities', 'wp-i18n'), 'version' => '9fb0d8db7b90d2ecdfb8');
