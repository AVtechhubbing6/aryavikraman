<?php return array('dependencies' => array('react', 'wc-components', 'wc-store-data', 'wc-tracks', 'wp-data', 'wp-element', 'wp-i18n'), 'version' => '5b32e7747adb7af0dc05');
