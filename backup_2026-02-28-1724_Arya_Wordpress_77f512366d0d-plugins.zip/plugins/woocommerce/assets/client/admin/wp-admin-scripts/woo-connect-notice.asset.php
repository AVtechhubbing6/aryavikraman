<?php return array('dependencies' => array('wc-tracks'), 'version' => '17588809cf4f84c12078');
